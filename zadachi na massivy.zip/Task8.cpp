#include <iostream>
using namespace std;

int main() {
    setlocale(LC_ALL, "Russian");
    int n, X[100], Y[100];
    cout << "n: ";
    cin >> n;

    cout << "������ X: ";
    for (int i = 0; i < n; i++) cin >> X[i];

    cout << "������ Y: ";
    for (int i = 0; i < n; i++) cin >> Y[i];

    for (int i = 0; i < n; i++) {
        bool ok = true;
        for (int j = 0; j < n; j++) {
            if (i + j >= n || X[i + j] != Y[j]) {
                ok = false;
                break;
            }
        }
        if (ok) {
            cout << "��" << endl;
            return 0;
        }
    }

    cout << "���" << endl;
    return 0;
}