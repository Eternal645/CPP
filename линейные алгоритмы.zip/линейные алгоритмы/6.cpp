#include <iostream>
#include <cmath>
#include <locale.h>

int main()
{
    setlocale(LC_ALL, "RU");
    float r;
    float a;
    std::cout << "Введите радиус: ";
    std::cin >> r;
    std::cout << "Введите сторону треугольника: ";
    std::cin >> a;
    
    if (r <= 0 || a <= 0) {
        std::cout << "Ошибка!" << std::endl;
        return 1;
    }
    
    if (2 * r > a) {
        std::cout << "Не поместится." << std::endl;
        return 0;
    }
    
    float root = std::sqrt(3);
    float h = a * root / 2;
    
    if (2 * r > h) {
        std::cout << "Не поместится." << std::endl;
        return 0;
    }
    
    float dy = r * root;
    int k = std::floor((h - 2 * r) / dy) + 1;
    
    int total = 0;
    
    for (int i = 1; i <= k; i++) {
        int row_count;
        
        if (i % 2 == 1) {
            row_count = std::floor((a - 2 * r) / (2 * r)) + 1;
        } else {
            row_count = std::floor((a - 2 * r) / (2 * r));
        }
        
        if (row_count > 0) {
            total += row_count;
        }
    }
    
    std::cout << "Кругов: " << total << std::endl;
    
    return 0;
}
