#include <iostream>
#include <locale.h>

int main()
{
    setlocale(LC_ALL, "RU");
    float r;
    float p = 3.14159;
    std::cout << "Введите радианы: ";
    std::cin >> r;
    float g;
    g = r * (180 / p);
    std::cout << "Ваш результат: " << g << std::endl;
    return 0;
}
