#include <iostream>
#include <cmath>
#include <locale.h>

int main()
{
    setlocale(LC_ALL, "RU");
    float a;
    float b;
    float c;
    std::cout << "Введите a: ";
    std::cin >> a;
    std::cout << "Введите b: ";
    std::cin >> b;
    std::cout << "Введите c: ";
    std::cin >> c;
    if (a == 0) {
        std::cout << "Это не парабола, так как коэффициент a равен 0." << std::endl;
        return 1;
    }
    float x0 = -b / (2 * a);
    float y0 = a * std::pow(x0, 2) + b * x0 + c;
    std::cout << "Координаты вершины параболы:" << std::endl;
    std::cout << "x0 = " << x0 << std::endl;
    std::cout << "y0 = " << y0 << std::endl;
    return 0;
}
