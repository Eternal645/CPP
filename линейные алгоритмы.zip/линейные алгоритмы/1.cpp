#include <iostream>
#include <locale.h>

int main()
{
    setlocale(LC_ALL, "RU");
    float g;
    float m;
    float s;
    float p = 3.14159;
    std::cout << "Введите градусы: ";
    std::cin >> g;
    std::cout << "Введите минуты: ";
    std::cin >> m;
    std::cout << "Введите секунды: ";
    std::cin >> s;
    float r;
    r = (g + (m / 60) + (s / 3600)) * (p / 180);
    std::cout << "Ваш результат: " << r << std::endl;
    return 0;   
}
