#include <iostream>
#include <locale.h>

int main()
{
    setlocale(LC_ALL, "RU");
    int h;
    int m;
    int s;
    std::cout << "Введите кол-во часов: ";
    std::cin >> h;
    std::cout << "Введите кол-во минут: ";
    std::cin >> m;
    std::cout << "Введите кол-во секунд: ";
    std::cin >> s;
    if (s > 30)
    {
        m = m + 1;
        if (m == 60) 
        {
            m = 0;
            h = h + 1;
            std::cout << h << " часов" << std::endl;
        }
        else if (m >= 50)
        {
            std::cout << h << " часов " << m << " минут" << " или ";
            h = h + 1;
            std::cout << h << " часов" << std::endl;
        }
        else
        {
            std::cout << h << " часов " << m << " минут" << " или " << h << " часов" << std::endl;
        }
    }
    else if (m >= 50)
        {
            std::cout << h << " часов " << m << " минут" << " или ";
            h = h + 1;
            std::cout << h << " часов" << std::endl;
        }
    else 
    {
        std::cout << h << " часов " << m << " минут" << " или " << h << " часов" << std::endl;
    }
    return 0;
}
