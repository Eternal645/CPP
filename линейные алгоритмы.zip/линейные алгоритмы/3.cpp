#include <iostream>
#include <cmath>
#include <locale.h>

int main() 
{
    setlocale(LC_ALL, "RU");
    int k;
    int p;
    int s;
    std::cout << "Стартовый капитал: ";
    std::cin >> k;
    std::cout << "Процент в месяц: ";
    std::cin >> p;
    std::cout << "Целевая сумма: ";
    std::cin >> s;
    if (k <= 0 || p <= 0 || s <= 0) {
        std::cout << "Ошибка: значения должны быть > 0" << std::endl;
        return 1;
    }
    int month = 0;
    int cur = k;
    const int MAX_M = 1200;
    while (cur < s && month < MAX_M) {
        cur = cur * (1 + p / 100.0);
        month++;
    }
    if (month >= MAX_M) {
        std::cout << "Цель не достигнута в разумные сроки" << std::endl;
        return 0;
    }
    int y = (month + 11) / 12;
    std::cout << "Нужно лет: " << y << std::endl;
    std::cout << "(Точно: " << month << " месяцев)" << std::endl;
    return 0;
}
